Code for https://indopak.quranwbw.com.
