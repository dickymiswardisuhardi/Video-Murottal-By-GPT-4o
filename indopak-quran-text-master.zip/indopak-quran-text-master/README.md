# Assalamu Alaikum wa rehmatullahi wa barakatahu,

We have done our best efforts to make available this Indopak Quran Text in the best of its form and Quality.

Preview image of an ayah:<br>
<img src="https://raw.githubusercontent.com/marwan/indopak-quran-text/master/ayah.png">

## For Madinah Version Text

We have Manually & Digitally Verified the Word-to-Word and Pausemark-to-Pausemark of this Quran Text with King Fahad Glorious Quran Printing Complex's Nastaleeq Text/Mushaf (v.10.0).

The Source of the Quran Text (digital file):
https://fonts.qurancomplex.gov.sa/wp02/hafs-nastaleek

The Indo-Pak/Nastaleeq Mushaf Official Link:
https://qurancomplex.gov.sa/en/kfgqpc-quran-hafs-nastaleeq/

## For Hanafi Version Text

We have used Indopak Text which was originally made by Inpage Quran Publishing Software and was made available on the internet by Ata Rafi of typemybook.com. (see source link below)

The original Hanafi text was made available in HTML format with AlQalam font. We then manually split the text into word by word and compared this text with King Fahad Glorious Quran Printing Complex's Nastaleeq Text/Mushaf and digitally identified the differences. We then manually checked the differences that were digitally identified between both the versions and made adjustments by manually verifying each and every word and Ayah icon with the 13 lines Indopak Hanafi Quran (Mushaf) {which is famously used in Indian Subcontinent Region}. (See below link).

The Source of the Quran Text (digital file):
https://typemybook.com/download/complete-quran-kareem-text/

The Indopak Hanafi Version Mushaf Link:
https://archive.org/details/QuranAl-majeed-13Line/1-QuraanAlMajeed13Line-Complete/

---

The Text & Font is based on Simple Ligatures, which makes the text easy to read by beginners and it is only the writing difference between the Mushaf and this digital Text. No other difference can be seen.

If you find any error, then please immediately send us the details with a screenshot (Text Version "Madinah or Hanafi", Surah Name and Ayah Number is a must) on "quranwbw@gmail.com or ayman24x7@gmail.com" and we will correct it In'Sha'Allah.

In'Sha'Allah there is no scope for any errors, but humans are made to errors and are not perfect.

_Important Note:_ This Indopak Quran Text is not fully Unicode Compatible (which means, no other font will work with these Text files) and will work only with the Included Font files.

## Special Font Requirement

We have made a custom font based on the old Al Qalam font that was included with the original text file. We created the font to solve some text issues and also to add some additional features.

The Indo-Pak Quran Text (v.9.6) (Both Madinah and Hanafi Versions) provided within this package is only compatible with the following special fonts:

(With Wakf-lazim Margin Indicators)

1. AlQuran-IndoPak-by-QuranWBW.v.4.2.1-WL.ttf
2. AlQuran-IndoPak-by-QuranWBW.v.4.2.1-WL.woff
3. AlQuran-IndoPak-by-QuranWBW.v.4.2.1-WL.woff2

(Without Wakf-lazim Margin Indicators)

1. AlQuran-IndoPak-by-QuranWBW.v.4.2.1.ttf
2. AlQuran-IndoPak-by-QuranWBW.v.4.2.1.woff
3. AlQuran-IndoPak-by-QuranWBW.v.4.2.1.woff2

The above two variants of the fonts are further available in three different Word Spacing Styles (Normal, Compact and Compressed) which works by default on Ayah by Ayah Text.

Important Note: The included Text files of both versions is only compatible with the included font files. These texts are not compatible with any of the older versions of these fonts or any other normal fonts.

## Live Preview

You can preview the data live on https://quranwbw.com (select the "Naskh Nastaleeq IndoPak" font type from settings).

## Credits

Made by: Ayman Siddiqui and R. Siddiqua for www.QuranWBW.com and www.Quran.com for Sadaqa-e-Jaria purposes only.

_DO NOT SELL, MANIPULATE, DISTRIBUTE WITHOUT CREDITS OR TAMPER IN ANY FORM OR MANNER._

Jazak'Allahu Khair.
